**Eigen's official git repository have been moved to https://gitlab.com/libeigen/eigen**

For convenience, this deprecated mirror repository will be kept as is for a short period of time before being **deleted**.

So please **update your git clones & submodules to https://gitlab.com/libeigen/eigen.git as soon as possible**.

Also note that it is not possible keep it sync with the new official git repository because the hashes do not match. 
